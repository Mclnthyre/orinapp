<?php $__env->startSection('content'); ?>
<h2>Vídeos</h2>
<p>Assista conteúdos sobre entidades e tradições.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vol9_5/infinityfree.com/if0_40513224/htdocs/resources/views/videos.blade.php ENDPATH**/ ?>