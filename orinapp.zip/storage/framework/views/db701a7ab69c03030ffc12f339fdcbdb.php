<?php $__env->startSection('content'); ?>
<h2>Artigos</h2>
<p>Em breve: Posts e ensinamentos.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vol9_5/infinityfree.com/if0_40513224/htdocs/resources/views/artigos.blade.php ENDPATH**/ ?>