<?php $__env->startSection('content'); ?>
<h2>Serviços</h2>
<p>Consulta espiritual, jogo de búzios e mais.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vol9_5/infinityfree.com/if0_40513224/htdocs/resources/views/servicos.blade.php ENDPATH**/ ?>