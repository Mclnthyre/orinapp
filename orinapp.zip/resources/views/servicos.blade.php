@extends('layout')

@section('content')
<h2>Serviços</h2>
<p>Consulta espiritual, jogo de búzios e mais.</p>
@endsection
