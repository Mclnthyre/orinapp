@extends('layout')

@section('content')
<h2>Bem-vindo ao ORIN</h2>
<p>Seu portal espiritual de Umbanda e Candomblé.</p>
@endsection
