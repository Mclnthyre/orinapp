@extends('layout')

@section('content')
<h2>Artigos</h2>
<p>Em breve: Posts e ensinamentos.</p>
@endsection
