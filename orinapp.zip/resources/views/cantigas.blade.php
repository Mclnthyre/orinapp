@extends('layout')

@section('content')
<h2>Cantigas</h2>
<p>Pontos tocados e cantados da Umbanda.</p>
@endsection
