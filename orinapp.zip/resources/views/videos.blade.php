@extends('layout')

@section('content')
<h2>Vídeos</h2>
<p>Assista conteúdos sobre entidades e tradições.</p>
@endsection
